from brain_games.games import progress


def main():
    print('Welcome to the Brain Games!')
    progress.progression()


if __name__ == '__main__':
    main()
