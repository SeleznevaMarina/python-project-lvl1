#!/usr/bin/env python

from brain_games import even


def main():
    print('Welcome to the Brain Games!')


#if __name__ == '__main__':
    #main()
main()
even.even_odd()


