#!/usr/bin/env python

from brain_games.games import even


def main():
    print('Welcome to the Brain Games!')
    even.even_odd()


if __name__ == '__main__':
    main()
